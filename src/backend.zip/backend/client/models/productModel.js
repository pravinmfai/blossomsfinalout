const mongoose = require('mongoose');

// Define the product schema
const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
    min: 0, // Price should not be negative
  },
  description: {
    type: String,
    required: true,
  },
  discountType: {
    type: String,
    enum: ['percentage', 'fixed'], // Restrict to valid discount types
    default: 'percentage', // Default discount type
  },
  discountPercentage: {
    type: Number,
    min: 0,
    max: 100, // Percentage should be between 0 and 100
    default: 0,
  },
  color: {
    type: [String], // Array of colors
    default: [],
  },
  material: {
    type: String,
    required: true,
  },
  size: {
    type: String,
    required: true,
  },
  quantity: {
    type: Number,
    required: true,
    min: 0, // Quantity should not be negative
  },
  category: {
    type: String,
    required: true,
  },
  tags: {
    type: [String], // Array of tags
    default: [],
  },
  imageUrl: {
    type: String,
    required: true,
  },
}, { timestamps: true }); // Automatically add createdAt and updatedAt timestamps

// Create the Product model
const Product = mongoose.model('Product', productSchema);

// Export the Product model
module.exports = Product;
